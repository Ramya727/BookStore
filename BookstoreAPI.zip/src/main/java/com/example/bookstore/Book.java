package com.example.bookstore;

import jakarta.persistence.*;

@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String genre;
    private int year;

    @ManyToOne
    @JoinColumn(name = "author_id")
    private Author author;

    public Book() {}
    // Getters and Setters
}
