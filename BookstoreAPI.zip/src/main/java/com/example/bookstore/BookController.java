package com.example.bookstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookRepository bookRepo;

    @GetMapping
    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }

    @PostMapping
    public Book createBook(@RequestBody Book book) {
        return bookRepo.save(book);
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
        Book book = bookRepo.findById(id).orElseThrow();
        book.setTitle(bookDetails.getTitle());
        book.setGenre(bookDetails.getGenre());
        book.setYear(bookDetails.getYear());
        return bookRepo.save(book);
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        bookRepo.deleteById(id);
    }

    @GetMapping("/filter")
    public List<Book> getByGenre(@RequestParam String genre) {
        return bookRepo.findByGenre(genre);
    }

    @GetMapping("/page")
    public Page<Book> getBooksPage(@RequestParam int page, @RequestParam int size) {
        return bookRepo.findAll(PageRequest.of(page, size));
    }

    @GetMapping("/sort")
    public List<Book> getSortedBooks(@RequestParam String field) {
        return bookRepo.findAll(Sort.by(field));
    }
}
